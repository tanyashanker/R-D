package com.tanya.parkingSystem.version2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.tanya.parkingSystem.CustomerDetails;
import com.tanya.parkingSystem.ParkingId;

public class Customer {

	Map<ParkingId, CustomerDetails> location;
	List<Map<ParkingId, CustomerDetails>> floorNo;
	List<List<Map<ParkingId, CustomerDetails>>> building;
	ParkingId id;
	int floorIndex = 1, sectionIndex = 1;
	int locationIndex = 1;

	public Customer() {
		location = new HashMap<>();
		floorNo = new ArrayList<>();
		building = new ArrayList<>();

	}

	public void addCar(CustomerDetails car) {
		if (floorIndex <= 4) {
			if (sectionIndex <= 4) {
				if (locationIndex <= 10) {
					id = new ParkingId(floorIndex, sectionIndex, locationIndex);
					car.setParkid(id);
					locationIndex++;
					location.put(id, car);
				} else {
					floorNo.add(location);
					sectionIndex++;
					location.clear();

					locationIndex = 1;
					id = new ParkingId(floorIndex, sectionIndex, locationIndex);
					car.setParkid(id);
					locationIndex++;
					location.put(id, car);

				}

			} else {
				building.add(floorNo);
				floorIndex++;
			}
		} else {
			if (building.size() > 4)
				throw new RuntimeException("Parking full!");
		}

	
	}
	
	public Map<ParkingId, CustomerDetails> getAllCars()
	{
		return location;
	}

}
