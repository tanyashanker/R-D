package com.tanya.parkingSystem.version2;

import java.util.Map;

import com.tanya.parkingSystem.CustomerDetails;
import com.tanya.parkingSystem.ParkingService;

public class Parking {

	public static void main(String[] args) {
		Customer car=new Customer();
		CustomerDetails c1=new CustomerDetails("Nikki","9876543210");
		CustomerDetails c2=new CustomerDetails("Tanya","9876543210");
		car.addCar(c1);
		car.addCar(c2);
		System.out.println(car.getAllCars());
		
	}
}
