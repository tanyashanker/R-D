package com.tanya.parkingSystem;

public class ParkingId {

    int floor;
    int section;
    int compartment;
    public ParkingId(int floor2, int section2, int compartment2) {
           super();
           this.floor = floor2;
           this.section = section2;
           this.compartment = compartment2;
    }
    public int getFloor() {
           return floor;
    }
    public void setFloor(int floor) {
           this.floor = floor;
    }
    public int getSection() {
           return section;
    }
    public void setSection(int section) {
           this.section = section;
    }
    public int getCompartment() {
           return compartment;
    }
//    
//    public String generateId(int floor,int section, int compartment)
//    {
//    	String id=floor+""+section+""+compartment;
//		return id;
//    	
//    }
    @Override
	public String toString() {
		return floor+""+section+""+compartment;
	}
	public void setCompartment(int compartment) {
           this.compartment = compartment;
    }

}
