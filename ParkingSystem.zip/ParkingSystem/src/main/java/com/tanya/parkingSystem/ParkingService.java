package com.tanya.parkingSystem;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class ParkingService {
	 static Map<ParkingId,CustomerDetails> carMap;
	 static int floor=1,section=1,compartment=1;
		
	 public ParkingService(){
	
		 carMap=new HashMap<>();
	 }
	 
	public void addCar(CustomerDetails car)
	{	
		if(compartment>10)
		{
			section++;
			compartment=1;
			if(section>4)
			{
				floor++;
				section=1;
				compartment=1;
			}
		}
	    ParkingId key=new ParkingId(floor,section,compartment);
	    
		carMap.put(key, car);
		compartment++;
		car.setParkid(key);
		
		//return key;
	}
	
	public Set<Map.Entry<ParkingId, CustomerDetails>> getAllCars() {
			
		return carMap.entrySet();
		
	}
	
	
	public CustomerDetails getCarById(ParkingId id) {
		
		return  carMap.get(id);
		
	}
	
	public static void main(String[] args) {
		ParkingService car=new ParkingService();
		CustomerDetails c1=new CustomerDetails("Nikki","9876543210");
		car.addCar(c1);
		car.addCar(new CustomerDetails("Tanya","9876543210"));
		for(Map.Entry m: carMap.entrySet())
			System.out.println(m.getKey()+ " : "+m.getValue());
		//System.out.println(car.getAllCars());
		
		
		System.out.println(car.getCarById(c1.getParkid()));
	}
}
