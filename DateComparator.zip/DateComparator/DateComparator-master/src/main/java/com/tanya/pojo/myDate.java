package com.tanya.pojo;

public class myDate {
	
	private int dd, mm, yyyy;

	public myDate(int dd, int mm, int yyyy) {
		
		this.dd = dd;
		this.mm = mm;
		this.yyyy = yyyy;
	}

	public int getDd() {
		return dd;
	}

	public int getMm() {
		return mm;
	}

	public int getYyyy() {
		return yyyy;
	}
		
}
