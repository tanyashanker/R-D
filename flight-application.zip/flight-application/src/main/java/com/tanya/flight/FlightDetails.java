package com.tanya.flight;




public class FlightDetails {

	int flightNo;
	String flightName;
	String destination;
	String source;
	int departureTime;
	int arrivalTime;
	int price;
	int routeTime;
	static int autoFlightNoGen;

	{
		flightNo = ++autoFlightNoGen;
	}

	public FlightDetails( String flightName, String destination, String source, int departureTime,
			int arrivalTime, int price) {
		super();

		this.flightName = flightName;
		this.destination = destination;
		this.source = source;
		this.departureTime = departureTime;
		this.arrivalTime = arrivalTime;
		this.price = price;
		this.routeTime=getRouteTime();

	}

	public int getFlightNo() {
		return flightNo;
	}

	
	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public int getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(int departureTime) {
		this.departureTime = departureTime;
	}

	public int getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(int arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getRouteTime() {
		if(arrivalTime<departureTime)
		{
			return 2400-departureTime+arrivalTime;
		}
		return arrivalTime-departureTime;

	}
		
	

	@Override
	public String toString() {
		return "FlightDetails [flightNo=" + flightNo + ", flightName=" + flightName + ", destination=" + destination
				+ ", source=" + source + ", departureTime=" + departureTime + ", arrivalTime=" + arrivalTime
				+ ", price=" + price + ", routeTime=" + routeTime + "]";
	}

}
