package com.tanya.flight.customer;

import com.tanya.flight.FlightDetails;
import com.tanya.flight.FlightService;

public class Customer {

	public static void main(String[] args) {
		FlightDetails f1=new FlightDetails("Air India","Lucknow","Delhi",1830,2230,1800);
		FlightDetails f2=new FlightDetails("SpiceJet","Lucknow","Mumbai",1830,0000,12600);
		FlightDetails f3=new FlightDetails("Vistara","Lucknow","Bangalore",0330,2230,9800);
		FlightDetails f4=new FlightDetails("Indigo","Lucknow","Leh",0630,1130,6900);
		FlightService flt=new FlightService();
		flt.addFlights(f1);
		flt.addFlights(f2);
		flt.addFlights(f3);
		flt.addFlights(f4);
		System.out.println(flt.getAllFlights());
		System.out.println(flt.sortByCost());
		System.out.println(flt.sortFlightByTime());
	}
	
}
