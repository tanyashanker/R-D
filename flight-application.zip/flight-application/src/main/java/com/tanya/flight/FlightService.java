package com.tanya.flight;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


public class FlightService {

	ArrayList<FlightDetails> flightList = new ArrayList<FlightDetails>();
	
	public void addFlights(FlightDetails flight)
	{	
		flightList.add(flight);
	}
	
	public ArrayList<FlightDetails> removeFlightByNo(int flightNo) {
		for (FlightDetails flight : flightList) {
			if (flight.getFlightNo() == flightNo)
				flightList.remove(flight);
			return flightList;
		}
		throw new RuntimeException("Flight no. invalid");
	}
	public ArrayList<FlightDetails> getAllFlights() {
		return flightList;
	}
	public FlightDetails getFlightByNo(int flightNo) {
		for (FlightDetails flight : flightList) {
			if (flight.getFlightNo() == flightNo)
				return flight;
		}
		throw new RuntimeException("Flight does not exist");
	}
	
	public ArrayList<FlightDetails> updateFlightBySource(int flightNo, String source) {
		for (FlightDetails flight : flightList) {
			if (flight.getFlightNo() == flightNo)
				flight.setSource(source);
				return flightList;
		}
		
		
		throw new RuntimeException("Flight does not exist");
	}
	
	public ArrayList<FlightDetails> updateFlightByDestination(int flightNo, String destination) {
		for (FlightDetails flight : flightList) {
			if (flight.getFlightNo() == flightNo)
				flight.setSource(destination);
				return flightList;
		}
		
		
		throw new RuntimeException("Flight does not exist");
	}
	
	
	public ArrayList<FlightDetails> updateFlightByDeparture(int flightNo, int departureTime) {
		for (FlightDetails flight : flightList) {
			if (flight.getFlightNo() == flightNo)
				flight.setDepartureTime(departureTime);
				return flightList;
		}
		
		
		throw new RuntimeException("Flight does not exist");
	}
	
	public ArrayList<FlightDetails> updateFlightByArrival(int flightNo, int arrivalTime) {
		for (FlightDetails flight : flightList) {
			if (flight.getFlightNo() == flightNo)
				flight.setArrivalTime(arrivalTime);
				return flightList;
		}
		
		
		throw new RuntimeException("Flight does not exist");
	}
	
	public ArrayList<FlightDetails> sortByCost()
	{
		Collections.sort(flightList, new Comparator<FlightDetails>() {
		    public int compare(FlightDetails flight1, FlightDetails flight2) {
		        return flight1.getPrice()-flight2.getPrice();
		    }
		});
		return flightList;
				
	}
	
	
	public ArrayList<FlightDetails> sortFlightByTime(){
        Collections.sort(flightList, new Comparator<FlightDetails>() {

               public int compare(FlightDetails flight1, FlightDetails flight2) {
                     return flight1.getRouteTime()-(flight2.getRouteTime());
               }
               
        });
        return flightList;
 }
 
 public ArrayList<FlightDetails> morningFlights()
{
        ArrayList<FlightDetails> morningFlights=new ArrayList<FlightDetails>();
        for (FlightDetails flight : flightList) {
               if (flight.getDepartureTime()>=600 && flight.getDepartureTime()<1200)
                     morningFlights.add(flight);
               return morningFlights;
        }

        throw new RuntimeException("flight does not exist");
 }

	
	
}
