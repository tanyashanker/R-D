package com.tanya.streamDemo;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class StreamOperation {

	public static void main(String[] args) {
		List<String> list=new ArrayList<String>();
		list.add("Tanya");
		list.add("Ashish");
		list.add("Nikki");
		list.add("Saifi");
		list.add("Nikki");
		list.add("  ");
		list.add("");
		
		
		Stream<String> s=list.stream();
		Stream<String> distinct=s.distinct();
		long count=distinct.count();
		
		//list.stream().distinct().count();
	System.out.println(list.stream().distinct().count());
	
	boolean anyMatch= list.stream().anyMatch(c->c.contains("zx"));
	System.out.println(anyMatch);
	
	}
}
