package com.tanya.streamDemo;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class ParallelStreamTest {
 public static void main(String[] args) {
	List<Student> list=new ArrayList<Student>();
	list.add(new Student("Tanya",22));
	list.add(new Student("Ramya",22));
	list.add(new Student("Kittu",22));
	list.add(new Student("Angshu",23));
	list.add(new Student("Nikki",107));
	list.add(new Student("Ashish",28));
	list.add(new Student("Saifi",06));
	
	/*Stream<Student> parallelStream=list.stream();
	parallelStream.forEach(s->doProcess(s));
	*/
	
	Stream<Student> filteredList=list.stream().filter(s->s.getAge()<23);
	filteredList.forEach(System.out::println);
}

/*private static void doProcess(Student s) {
	System.out.println(s);
}*/
}
