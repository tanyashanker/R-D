package com.tanya.streamDemo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class ClientTest {

	public static void main(String[] args) {
		String arr[]=new String[] {"Tanya","is","my","name"};
		Stream<String> stream=Arrays.stream(arr);
		stream.forEach(System.out::println);
		
		System.out.println("===========================");
		
		Stream<String> st=Stream.of("Nikki","is","a","good person");
		st.forEach(System.out::println);
		
		System.out.println("===========================");
		
		List<String> list=new ArrayList<String>();
		list.add("Tanya");
		list.add("Ashish");
		list.add("Nikki");
		list.add("Saifi");
		
		Stream<String> s=list.stream();
		s.forEach(System.out::println);
	}
}
