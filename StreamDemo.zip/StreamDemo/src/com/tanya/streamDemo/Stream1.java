package com.tanya.streamDemo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class Stream1 {

                public static void main(String[] args) {
                                String a[]=new String[]{"Tanu","tanya","saifi"};
                                Stream<String> stream=Arrays.stream(a);
                                stream.forEach(System.out::println);
                                
                                Stream<String> of=Stream.of("A","b","c");
                                of.forEach(System.out::println);
                                
                                List<String> list=new ArrayList<>();
                                list.add("Nikhil");
                                list.add("Vishnu");
                                list.add("Ashish");
                                Stream<String> stream2=list.stream();
                                stream2.forEach(System.out::println);
                }
}
