package com.tanya.lambda;

public class TestClass {
	public static void main(String[] args) {
		
	/*MyInterface1 myInterface = () -> System.out.println("Lambda 1..");
	MyInterface1 myInterface1 = () -> System.out.println("Lambda 2..");
	myInterface1.method1();
	
	myInterface1.method1();
	System.out.println("------------");
	MyInterface2 myInterface2=(n1,n2) -> n1>n2;
	boolean value=myInterface2. method2(96,87);
	System.out.println("Is n1>n2: "+value);
	System.out.println("------------");
	*/
	
	String s1=new String("Hello");
	String s2="Hello";
	System.out.println(s1.hashCode()==s2.hashCode());
	System.out.println(s1==s2);
	
	}
}
