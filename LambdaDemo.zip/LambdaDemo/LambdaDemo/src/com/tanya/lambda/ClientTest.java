package com.tanya.lambda;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class ClientTest {

	public static void main(String[] args) {
		
		List<Integer> integers= Arrays.asList(3,9,7,0,10,20);
		integers.forEach(lambdaWrapper(i->System.out.println(50/i), Exception.class));
	}

	private static <Integer, E extends Exception> Consumer<Integer> lambdaWrapper(Consumer<Integer> consumer, Class<E> clazz){
		return i->{
			try
			{
				consumer.accept(i);
			}
			catch(Exception ex)
			{
				try {
					E exCast= clazz.cast(ex);
					System.err.println("Exception occured: "+ exCast.getMessage());
				}
				catch(ClassCastException exC)
				{
					throw new RuntimeException(exC);
				}
			}
		};
}
}
